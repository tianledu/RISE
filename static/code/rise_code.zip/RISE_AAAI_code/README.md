# RISE:

## Setup

```bash
pip install -r requirements.txt
```

## Reproduce the LOLv1 result

Run from this directory:

```bash
python infer.py
```

Predictions are written to `results/LOLv1/pred`. PSNR, SSIM, and AlexNet
LPIPS are computed with the implementation in `measure.py` and written to
`results/LOLv1/metrics.txt`.

Expected result for the bundled 15-image test set:

| PSNR | SSIM | LPIPS |
| ---: | ---: | ---: |
| 20.2126 | 0.771697 | 0.218895 |

All paths in `config.yaml` are relative to this package directory. To process
another input directory without reference images:

```bash
python infer.py --input-dir images --output-dir results/custom --skip-metrics
```

Use `--device cpu`, `--device cuda`, or `--device cuda:N` to select a device.
