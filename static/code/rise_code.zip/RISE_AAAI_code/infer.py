from __future__ import annotations

import argparse
from pathlib import Path

from kornia.filters import guided_blur
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
import yaml

from measure import MetricEvaluator
from model import ReIFNet


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp"}
PROJECT_ROOT = Path(__file__).resolve().parent


def project_path(value: str | Path) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else PROJECT_ROOT / path


def load_image(path: Path) -> torch.Tensor:
    array = np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8).copy()
    return torch.from_numpy(array).permute(2, 0, 1).contiguous().float().div(255.0)


def tensor_to_uint8(tensor: torch.Tensor) -> np.ndarray:
    tensor = tensor.detach().float().cpu().clamp(0, 1)
    return (
        tensor.squeeze(0).permute(1, 2, 0).numpy() * 255.0
    ).round().astype(np.uint8)


def preprocess(
    image: torch.Tensor, gamma: float, kernel_size: int, epsilon: float
) -> torch.Tensor:
    image = image.clamp(0, 1).pow(float(gamma))
    if kernel_size > 1 and epsilon > 0:
        image = guided_blur(
            image.unsqueeze(0),
            image.unsqueeze(0),
            kernel_size=[kernel_size, kernel_size],
            eps=float(epsilon),
            border_type="reflect",
        ).squeeze(0)
    return image


def pad_to_patch_multiple(
    tensor: torch.Tensor, patch_size: tuple[int, int]
) -> torch.Tensor:
    patch_height, patch_width = patch_size
    height, width = tensor.shape[-2:]
    pad_height = (-height) % patch_height
    pad_width = (-width) % patch_width
    return F.pad(tensor, (0, pad_width, 0, pad_height), mode="replicate")


def collect_images(directory: Path) -> list[Path]:
    if not directory.is_dir():
        raise FileNotFoundError(f"Image directory not found: {directory}")
    return sorted(
        path
        for path in directory.rglob("*")
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def target_map(directory: Path) -> dict[str, Path]:
    return {path.stem.lower(): path for path in collect_images(directory)}


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError("The top level of the config must be a mapping.")
    return config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="ReIF LSRW-Nikon checkpoint inference on LOLv1"
    )
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--checkpoint", default=None)
    parser.add_argument("--input-dir", default=None)
    parser.add_argument("--target-dir", default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, or cuda:N")
    parser.add_argument("--use-gt-mean", action="store_true")
    parser.add_argument("--skip-metrics", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(project_path(args.config))
    data_config = config["data"]
    model_config = config["model"]

    checkpoint_path = project_path(args.checkpoint or config["checkpoint"])
    input_directory = project_path(args.input_dir or data_config["input_dir"])
    output_directory = project_path(args.output_dir or config["output_dir"])
    target_value = args.target_dir or data_config.get("target_dir")
    target_directory = (
        project_path(target_value)
        if target_value and not args.skip_metrics
        else None
    )

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    patch_width, patch_height = model_config["patch_size"]
    patch_size = (int(patch_height), int(patch_width))
    model = ReIFNet(
        in_channels=int(model_config["in_channels"]),
        base_channels=int(model_config["base_channels"]),
        patch_size=patch_size,
        anchor_num=int(model_config["anchor_num"]),
    ).to(device)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval()

    input_paths = collect_images(input_directory)
    if not input_paths:
        raise RuntimeError(f"No input images found in {input_directory}")
    targets = target_map(target_directory) if target_directory is not None else {}
    prediction_directory = output_directory / "pred"
    prediction_directory.mkdir(parents=True, exist_ok=True)
    rows: list[tuple[str, float, float, float]] = []
    evaluator = (
        MetricEvaluator(device, use_gt_mean=args.use_gt_mean)
        if target_directory is not None
        else None
    )

    print(f"Device: {device}")
    print(f"Images: {len(input_paths)}")
    with torch.inference_mode():
        for index, input_path in enumerate(input_paths, start=1):
            raw_input = load_image(input_path)
            original_height, original_width = raw_input.shape[-2:]
            network_input = preprocess(
                raw_input,
                gamma=float(data_config["gamma"]),
                kernel_size=int(data_config["guided_filter_kernel"]),
                epsilon=float(data_config["guided_filter_epsilon"]),
            )
            network_batch = pad_to_patch_multiple(
                network_input.unsqueeze(0), patch_size
            ).to(device)

            restored = model(network_batch)
            restored = restored[..., :original_height, :original_width]
            restored_image = tensor_to_uint8(restored)
            save_path = prediction_directory / f"{input_path.stem}.png"
            Image.fromarray(restored_image, mode="RGB").save(save_path)

            if target_directory is not None:
                target_path = targets.get(input_path.stem.lower())
                if target_path is None:
                    raise FileNotFoundError(
                        f"No paired target for {input_path.name}"
                    )
                assert evaluator is not None
                psnr, ssim, lpips_value = evaluator.measure(
                    save_path, target_path
                )
                rows.append((input_path.stem, psnr, ssim, lpips_value))
                print(
                    f"[{index:02d}/{len(input_paths):02d}] {input_path.stem}: "
                    f"PSNR={psnr:.4f}, SSIM={ssim:.6f}, "
                    f"LPIPS={lpips_value:.6f}"
                )
            else:
                print(f"[{index:02d}/{len(input_paths):02d}] {input_path.stem}")

    if rows:
        average_psnr = sum(row[1] for row in rows) / len(rows)
        average_ssim = sum(row[2] for row in rows) / len(rows)
        average_lpips = sum(row[3] for row in rows) / len(rows)
        metrics_path = output_directory / "metrics.txt"
        with metrics_path.open("w", encoding="utf-8") as handle:
            handle.write("rank\tname\tpsnr\tssim\tlpips\n")
            for rank, row in enumerate(
                sorted(rows, key=lambda item: item[1], reverse=True), start=1
            ):
                handle.write(
                    f"{rank}\t{row[0]}\t{row[1]:.4f}\t{row[2]:.6f}\t"
                    f"{row[3]:.6f}\n"
                )
            handle.write(
                f"AVERAGE\t-\t{average_psnr:.4f}\t{average_ssim:.6f}\t"
                f"{average_lpips:.6f}\n"
            )
        print(
            f"Average: PSNR={average_psnr:.4f}, SSIM={average_ssim:.6f}, "
            f"LPIPS={average_lpips:.6f}"
        )
        print(f"Metrics: {metrics_path}")
    print(f"Predictions: {prediction_directory}")


if __name__ == "__main__":
    main()
