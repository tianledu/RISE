from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


FORMULA_EPS = 1e-3
MIN_ANCHOR_DISTANCE = 2.0
TAU = 0.001
RQ_LAMBDA = 1.0
COEFFICIENT_RANGE = 2.0
ETA_RANGE = 3.0
ANCHOR_TARGET_LOW = 0.05
ANCHOR_TARGET_HIGH = 0.95


def rgb_to_y(x: torch.Tensor) -> torch.Tensor:
    return 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]


def gather_patch_value(x: torch.Tensor, index: torch.Tensor) -> torch.Tensor:
    return torch.gather(x.view(x.shape[0], -1), 1, index)


def gather_patch_feature(x: torch.Tensor, index: torch.Tensor) -> torch.Tensor:
    batch, channels, _, _ = x.shape
    x = x.view(batch, channels, -1)
    index = index.unsqueeze(1).expand(batch, channels, index.shape[1])
    return torch.gather(x, 2, index).permute(0, 2, 1).contiguous()


class ConvBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, stride, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.body(x)


class ResBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(channels, channels, 3, 1, 1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(channels, channels, 3, 1, 1, bias=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.body(x)


class ImageEncoder(nn.Module):
    def __init__(self, in_channels: int, base_channels: int) -> None:
        super().__init__()
        self.head = ConvBlock(in_channels, base_channels)
        self.res1 = ResBlock(base_channels)
        self.down1 = ConvBlock(base_channels, base_channels * 2, stride=2)
        self.res2 = ResBlock(base_channels * 2)
        self.down2 = ConvBlock(base_channels * 2, base_channels * 4, stride=2)
        self.res3 = ResBlock(base_channels * 4)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feature = self.res1(self.head(x))
        context = self.res2(self.down1(feature))
        context = self.res3(self.down2(context))
        global_feature = F.adaptive_avg_pool2d(context, 1).flatten(1)
        return feature, global_feature


class MLPHead(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, out_dim: int) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.body(x)


class ReIFNet(nn.Module):
    """Inference-only ReIF model."""

    def __init__(
        self,
        in_channels: int = 3,
        base_channels: int = 16,
        patch_size: tuple[int, int] = (50, 75),
        anchor_num: int = 3,
    ) -> None:
        super().__init__()
        self.anchor_num = int(anchor_num)
        self.patch_size = tuple(int(value) for value in patch_size)
        self.min_anchor_distance = MIN_ANCHOR_DISTANCE
        self.tau = TAU
        self.rq_lam = RQ_LAMBDA
        self.coef_range = COEFFICIENT_RANGE
        self.eta_range = ETA_RANGE
        self.anchor_target_low = ANCHOR_TARGET_LOW
        self.anchor_target_high = ANCHOR_TARGET_HIGH

        self.raw_encoder = ImageEncoder(in_channels, base_channels)
        self.inv_encoder = ImageEncoder(1, base_channels)
        raw_dim = base_channels * 4
        inverse_dim = base_channels * 4
        patch_dim = base_channels
        self.anchor_head = MLPHead(
            raw_dim + inverse_dim + patch_dim * 2 + 1, base_channels * 4, 1
        )
        self.coef_head = MLPHead(
            inverse_dim + patch_dim + 3 + self.anchor_num * 2,
            base_channels * 4,
            13,
        )
        self.eta_head = MLPHead(raw_dim + 1, base_channels * 4, 1)

    def select_anchor_indices(self, patch_y: torch.Tensor) -> torch.Tensor:
        batch, _, grid_height, grid_width = patch_y.shape
        flat = patch_y.view(batch, -1)
        yy = (
            torch.arange(grid_height, device=patch_y.device)
            .view(grid_height, 1)
            .expand(grid_height, grid_width)
            .reshape(-1)
            .float()
        )
        xx = (
            torch.arange(grid_width, device=patch_y.device)
            .view(1, grid_width)
            .expand(grid_height, grid_width)
            .reshape(-1)
            .float()
        )

        batch_indices = []
        for batch_index in range(batch):
            scores = flat[batch_index].clone()
            chosen = []
            for _ in range(self.anchor_num):
                index = torch.argmax(scores)
                chosen.append(index)
                distance = torch.sqrt((yy - yy[index]) ** 2 + (xx - xx[index]) ** 2)
                scores[distance <= self.min_anchor_distance] = -1e6
            batch_indices.append(torch.stack(chosen, dim=0))
        return torch.stack(batch_indices, dim=0).long()

    @staticmethod
    def anchor_coordinates(
        anchor_indices: torch.Tensor, grid_width: int
    ) -> tuple[torch.Tensor, torch.Tensor]:
        return (
            (anchor_indices // grid_width).float(),
            (anchor_indices % grid_width).float(),
        )

    def rational_kernel(
        self,
        grid_y: torch.Tensor,
        grid_x: torch.Tensor,
        anchor_y: torch.Tensor,
        anchor_x: torch.Tensor,
        grid_height: int,
        grid_width: int,
    ) -> torch.Tensor:
        diagonal = math.sqrt(float(grid_height**2 + grid_width**2)) + 1e-6
        dy = grid_y.unsqueeze(0) - anchor_y.view(anchor_y.shape[0], 1, 1)
        dx = grid_x.unsqueeze(0) - anchor_x.view(anchor_x.shape[0], 1, 1)
        distance = torch.sqrt(dy**2 + dx**2) / diagonal
        return 1.0 / (1.0 + self.rq_lam * distance)

    def compute_formula_gain(
        self,
        z_map: torch.Tensor,
        anchor_z: torch.Tensor,
        coefficient_w: torch.Tensor,
        coefficient_u: torch.Tensor,
        coefficient_v: torch.Tensor,
        coefficient_b: torch.Tensor,
        coefficient_beta: torch.Tensor,
        eta: torch.Tensor,
        inverse_condition: torch.Tensor,
        anchor_indices: torch.Tensor,
    ) -> torch.Tensor:
        batch, _, grid_height, grid_width = z_map.shape
        grid_y = (
            torch.arange(grid_height, device=z_map.device)
            .view(grid_height, 1)
            .expand(grid_height, grid_width)
            .float()
        )
        grid_x = (
            torch.arange(grid_width, device=z_map.device)
            .view(1, grid_width)
            .expand(grid_height, grid_width)
            .float()
        )
        anchor_y, anchor_x = self.anchor_coordinates(anchor_indices, grid_width)

        formula_gain = coefficient_b.view(batch, 1, 1) + eta.view(batch, 1, 1)
        beta_term = torch.sum(
            coefficient_beta * inverse_condition, dim=1, keepdim=True
        ).view(batch, 1, 1)
        formula_gain = formula_gain + beta_term

        z_map_2d = z_map[:, 0]
        for anchor_index in range(self.anchor_num):
            kernel = self.rational_kernel(
                grid_y,
                grid_x,
                anchor_y[:, anchor_index],
                anchor_x[:, anchor_index],
                grid_height,
                grid_width,
            )
            delta_z = anchor_z[:, anchor_index].view(batch, 1, 1) - z_map_2d
            formula_gain = formula_gain + coefficient_w[:, anchor_index].view(
                batch, 1, 1
            ) * delta_z
            formula_gain = formula_gain + coefficient_u[:, anchor_index].view(
                batch, 1, 1
            ) * kernel * delta_z
            formula_gain = (
                formula_gain
                + coefficient_v[:, anchor_index].view(batch, 1, 1)
                * kernel
                * anchor_z[:, anchor_index].view(batch, 1, 1)
            )
        return formula_gain.unsqueeze(1)

    def forward(self, input_image: torch.Tensor) -> torch.Tensor:
        batch, _, height, width = input_image.shape
        patch_y = F.avg_pool2d(
            rgb_to_y(input_image), self.patch_size, self.patch_size
        )
        mean_low = patch_y.mean(dim=(2, 3), keepdim=True)
        normalized_y = torch.clamp(
            patch_y / (mean_low + FORMULA_EPS), min=self.tau
        )
        z_map = torch.log(normalized_y)

        raw_patch_feature, raw_global_feature = self.raw_encoder(input_image)
        raw_patch_feature = F.avg_pool2d(
            raw_patch_feature, self.patch_size, self.patch_size
        )
        inverse_patch_feature, inverse_global_feature = self.inv_encoder(z_map)

        anchor_indices = self.select_anchor_indices(patch_y.detach())
        anchor_low_y = gather_patch_value(patch_y[:, 0], anchor_indices)
        anchor_z = gather_patch_value(z_map[:, 0], anchor_indices)
        raw_anchor_feature = gather_patch_feature(raw_patch_feature, anchor_indices)
        inverse_anchor_feature = gather_patch_feature(
            inverse_patch_feature, anchor_indices
        )
        inverse_anchor_mean = inverse_anchor_feature.mean(dim=1)

        std_z = z_map.view(batch, -1).std(dim=1, unbiased=False)
        anchor_mean_normalized = gather_patch_value(
            normalized_y[:, 0], anchor_indices
        ).mean(dim=1)
        anchor_spread = anchor_z.max(dim=1)[0] - anchor_z.min(dim=1)[0]
        inverse_condition = torch.stack(
            (
                torch.log(anchor_mean_normalized + FORMULA_EPS),
                std_z,
                anchor_spread,
            ),
            dim=1,
        )

        raw_global_expanded = raw_global_feature.unsqueeze(1).expand(
            -1, self.anchor_num, -1
        )
        inverse_global_expanded = inverse_global_feature.unsqueeze(1).expand(
            -1, self.anchor_num, -1
        )
        anchor_input = torch.cat(
            (
                raw_anchor_feature,
                inverse_anchor_feature,
                raw_global_expanded,
                inverse_global_expanded,
                anchor_low_y.unsqueeze(-1),
            ),
            dim=2,
        )
        anchor_prediction = self.anchor_head(
            anchor_input.view(-1, anchor_input.shape[-1])
        )
        anchor_prediction = torch.sigmoid(anchor_prediction).view(
            batch, self.anchor_num
        )
        anchor_prediction = self.anchor_target_low + (
            self.anchor_target_high - self.anchor_target_low
        ) * anchor_prediction

        coefficient_input = torch.cat(
            (
                inverse_global_feature,
                inverse_anchor_mean,
                inverse_condition,
                anchor_prediction,
                anchor_z,
            ),
            dim=1,
        )
        coefficients = self.coef_range * torch.tanh(
            self.coef_head(coefficient_input)
        )
        coefficient_b = coefficients[:, 0]
        coefficient_w = coefficients[:, 1:4]
        coefficient_u = coefficients[:, 4:7]
        coefficient_v = coefficients[:, 7:10]
        coefficient_beta = coefficients[:, 10:13]

        eta_input = torch.cat(
            (raw_global_feature, torch.log(mean_low.view(batch, 1) + FORMULA_EPS)),
            dim=1,
        )
        eta = self.eta_range * torch.tanh(self.eta_head(eta_input)).view(batch)
        formula_log_gain = self.compute_formula_gain(
            z_map,
            anchor_z,
            coefficient_w,
            coefficient_u,
            coefficient_v,
            coefficient_b,
            coefficient_beta,
            eta,
            inverse_condition,
            anchor_indices,
        )
        log_gain = F.interpolate(
            formula_log_gain, size=(height, width), mode="bilinear", align_corners=False
        )
        return torch.clamp(input_image * torch.exp(log_gain), 0, 1)
