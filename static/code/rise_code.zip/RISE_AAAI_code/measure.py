"""Portable PSNR, SSIM, and LPIPS evaluation from ATP/measure.py."""

from __future__ import annotations

from pathlib import Path

import cv2
import lpips
import numpy as np
from PIL import Image
import torch


def ssim(prediction: np.ndarray, target: np.ndarray) -> float:
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    image1 = prediction.astype(np.float64)
    image2 = target.astype(np.float64)
    kernel = cv2.getGaussianKernel(11, 1.5)
    window = np.outer(kernel, kernel.transpose())
    mean1 = cv2.filter2D(image1, -1, window)[5:-5, 5:-5]
    mean2 = cv2.filter2D(image2, -1, window)[5:-5, 5:-5]
    mean1_squared = mean1**2
    mean2_squared = mean2**2
    mean12 = mean1 * mean2
    image1_squared = np.empty_like(image1)
    image2_squared = np.empty_like(image2)
    image12 = np.empty_like(image1)
    np.square(image1, out=image1_squared)
    np.square(image2, out=image2_squared)
    np.multiply(image1, image2, out=image12)
    variance1 = (
        cv2.filter2D(image1_squared, -1, window)[5:-5, 5:-5]
        - mean1_squared
    )
    variance2 = (
        cv2.filter2D(image2_squared, -1, window)[5:-5, 5:-5]
        - mean2_squared
    )
    covariance = (
        cv2.filter2D(image12, -1, window)[5:-5, 5:-5] - mean12
    )
    score_map = ((2 * mean12 + c1) * (2 * covariance + c2)) / (
        (mean1_squared + mean2_squared + c1)
        * (variance1 + variance2 + c2)
    )
    return float(score_map.mean())


def calculate_ssim(target: np.ndarray, reference: np.ndarray) -> float:
    image1 = np.array(target, dtype=np.float64)
    image2 = np.array(reference, dtype=np.float64)
    if image1.shape != image2.shape:
        raise ValueError("Input images must have the same dimensions.")
    if image1.ndim == 2:
        return ssim(image1, image2)
    if image1.ndim == 3 and image1.shape[2] == 3:
        return float(
            np.array(
                [
                    ssim(image1[:, :, channel], image2[:, :, channel])
                    for channel in range(3)
                ]
            ).mean()
        )
    if image1.ndim == 3 and image1.shape[2] == 1:
        return ssim(np.squeeze(image1), np.squeeze(image2))
    raise ValueError("Wrong input image dimensions.")


def calculate_psnr(target: np.ndarray, reference: np.ndarray) -> float:
    image1 = np.array(target, dtype=np.float32)
    image2 = np.array(reference, dtype=np.float32)
    difference = image1 - image2
    return float(
        10.0
        * np.log10(
            255.0 * 255.0 / (np.mean(np.square(difference)) + 1e-8)
        )
    )


class MetricEvaluator:
    def __init__(self, device: torch.device, use_gt_mean: bool = False) -> None:
        self.device = device
        self.use_gt_mean = bool(use_gt_mean)
        self.lpips_model = lpips.LPIPS(net="alex").to(device)

    @torch.inference_mode()
    def measure(
        self, prediction_path: str | Path, target_path: str | Path
    ) -> tuple[float, float, float]:
        prediction = Image.open(prediction_path).convert("RGB")
        target = Image.open(target_path).convert("RGB")
        prediction = prediction.resize(target.size)
        prediction_array = np.array(prediction)
        target_array = np.array(target)

        if self.use_gt_mean:
            prediction_mean = cv2.cvtColor(
                prediction_array, cv2.COLOR_RGB2GRAY
            ).mean()
            target_mean = cv2.cvtColor(
                target_array, cv2.COLOR_RGB2GRAY
            ).mean()
            prediction_array = np.clip(
                prediction_array * (target_mean / prediction_mean), 0, 255
            )

        psnr_value = calculate_psnr(prediction_array, target_array)
        ssim_value = calculate_ssim(prediction_array, target_array)
        prediction_tensor = lpips.im2tensor(prediction_array).to(self.device)
        target_tensor = lpips.im2tensor(target_array).to(self.device)
        lpips_value = float(
            self.lpips_model.forward(target_tensor, prediction_tensor).item()
        )
        if self.device.type == "cuda":
            torch.cuda.empty_cache()
        return psnr_value, ssim_value, lpips_value
